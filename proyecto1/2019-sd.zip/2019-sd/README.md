# CI5437 Inteligencia Artificial I

## Septiembre - Diciembre 2019

### Encargados:
* Prof. Blai Bonet &lt;bonet@usb.ve&gt;

### Horario:
* Lunes 3-4 (10:00 - 12:00 am) en MYS-015
* Mi&eacute;ercoles 3-4 (10:00 - 12:00 am) en MYS-015
* Viernes 3-4 (10:00 - 12:00 am) en MYS-015

### Proyectos
* Proyecto 1: B&uacute;squeda heur&iacute;stica

### Lista de clase:
* 09-10894 Ricardo Andres Vethencourt Mistage
* 10-10548 Pedro Miguel Perez Gonzalez
* 11-10569 Francisco Marcos Lombardi
* 12-10199 Nairelys Josefina Hernandez Sanchez
* 12-10578 Fabio Daniel Suárez Gorrín
* 12-10706 Ronald Alfonso Becerra Gil
* 13-10000 Constanza Yulai Abarca Sarmiento
* 13-10173 José Donato Bracuto Delgado
* 13-10805 Irina Antoinette Marcano Fadlallah
* 13-10856 Lucio David Mederos Duque
* 13-10931 Ángel Jesús Morante Martínez
* 13-11000 Christian Alexander Oliveros Labrador
* 13-11270 Denylson Alejandro Romero Contreras
* 13-11303 Abelardo Jose Salazar Patiño
* 13-11389 Giulianne Vanessa Tavano Rangel
* 14-10205 Aurivan Mariana Castro Rangel
* 14-10526 Mariagabriela Jaimes  Hidalgo
* 14-10820 Julio Cesar Perez Duran
* 14-10880 Yuni Amaloa Quintero Villalobos
* 14-10924 German Alexander Robayo Paz
* 14-11082 Andrés Ignacio Torres Molina
* 14-11130 Sandra Sofía Vera López

